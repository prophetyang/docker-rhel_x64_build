#include "foo.h"

int foo(int a1, int a2)
{
	return a1 * a2;
}
