#ifndef CMOCK_TEST_FOO_H_
#define CMOCK_TEST_FOO_H_

#ifdef __cplusplus
extern "C" {
#endif

int foo(int a1, int a2);

#ifdef __cplusplus
}
#endif

#endif /* CMOCK_TEST_FOO_H_ */
