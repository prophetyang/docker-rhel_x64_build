#include "foo_mock.h"

IMPLEMENT_FUNCTION_MOCK2(FooFunctionMock, foo, int(int, int));
